//
//  FFBannerViewCell.h
//  FFBannerView
//
//  Created by Fan on 16/10/10.
//  Copyright © 2016年 Fan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FFBannerViewCell : UICollectionViewCell
@property(nonatomic, strong) UIImageView *imageView;
@end
