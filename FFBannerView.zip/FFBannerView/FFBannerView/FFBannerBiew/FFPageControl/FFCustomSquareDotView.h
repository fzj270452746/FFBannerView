//
//  FFCustomSquareDotView.h
//  FFBannerView
//
//  Created by Fan on 16/10/12.
//  Copyright © 2016年 Fan. All rights reserved.
//

#import "FFAbstractDotView.h"

@interface FFCustomSquareDotView : FFAbstractDotView

@end
