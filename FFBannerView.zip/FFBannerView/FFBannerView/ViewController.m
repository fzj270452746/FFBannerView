//
//  ViewController.m
//  FFBannerView
//
//  Created by Fan on 16/10/10.
//  Copyright © 2016年 Fan. All rights reserved.
//

#import "ViewController.h"
#import "FFBannerView.h"

@interface ViewController () <FFBannerViewDelegate>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self setupLocalBannerImageView];
    [self setupNetWorkBannerImageView];
}

/**
 *  加载本地图片Banner
 */
- (void)setupLocalBannerImageView
{
    NSArray *array = @[@"1.png", @"2.png", @"3.png", @"4.png", @"5.png"];
    
    FFBannerView *bannerVew = [FFBannerView bannerViewWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 200) locationImageArray:array];
    bannerVew.timeInterval = 2.0;
    [self.view addSubview:bannerVew];
}

/**
 *  加载网络图片Banner
 */
- (void)setupNetWorkBannerImageView
{
    NSArray *array = @[@"http://i3.download.fd.pchome.net/t_960x600/g1/M00/07/09/oYYBAFMv8q2IQHunACi90oB0OHIAABbUQAAXO4AKL3q706.jpg",
                       @"http://images.weiphone.net/attachments/photo/Day_120308/118871_91f6133116504086ed1b82e0eb951.jpg",
                       @"http://benyouhuifile.it168.com/forum/macos/attachments/month_1104/110425215921926a173e0f728e.jpg",
                       @"http://benyouhuifile.it168.com/forum/macos/attachments/month_1104/1104241737046031b3a754f783.jpg"];
    
    FFBannerView *bannerVew = [FFBannerView bannerViewWithFrame:CGRectMake(0, 250, [UIScreen mainScreen].bounds.size.width, 200) netWorkImageArray:array placeHolderImage:nil];
    bannerVew.timeInterval = 2.0;
    bannerVew.pageControlStyle = FFPageControlStyleMiddle;
    bannerVew.delegate = self;
    [self.view addSubview:bannerVew];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - FFBannerViewDelegate
- (void)ffBannerViewClickCurrentIndex:(NSInteger)index
{
    NSLog(@"点击了第%ld个banner", index+1);
}
@end
